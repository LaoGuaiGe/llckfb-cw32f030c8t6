说明：
Documents：存放说明文档
IdeSupport：MDK和IAR的支持文件
Libraries：     驱动库
Examples：   工程样例目录
Utilities:        公共组件